
<?php

include 'components/wishlist_cart.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
}; 

?>



<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO images (title, description, image_path) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([$title, $description, $target_file])) {
            $upload_message = "Your request for the dress". basename($image). " has been uploaded successfully. We will let you when it is available.";
        } else {
            $upload_message = "Error: Unable to execute the query.";
        }
    } else {
        $upload_message = "Sorry, there was an error uploading your file.";
    }
}

// Fetch uploaded images
$sql = "SELECT title, description, image_path FROM images";
$stmt = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Asian Store | Cloud Platform</title>
   <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
</head>


<body>
    <?php include 'components/user_header.php'; ?>
     <br><br><br>

<h1 class="heading">Customize Your Choice</h1>

<div class="container">
    <h2>Upload Desired Dress:</h2>
    <?php if(isset($upload_message)) { echo '<div class="alert alert-info">'.$upload_message.'</div>'; } ?>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Brand Name:</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="description">Dress Description:</label>
            <textarea class="form-control" id="description" name="description" required></textarea>
        </div>
        <div class="form-group">
            <label for="image">Select Dress Image:</label>
            <input type="file" class="form-control-file" id="image" name="image" required>
        </div>
        <button type="submit" class="btn btn-primary">Upload</button>
    </form>
    <hr>
    <h2>Requested Dress Detail:</h2>
    <div class="row">
        <?php
        if ($stmt->rowCount() > 0) {
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo '<div class="col-md-4">';
                echo '<div class="card mb-4">';
                echo '<img src="'. $row["image_path"] .'" class="card-img-top" alt="'. $row["title"] .'">';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">'. $row["title"] .'</h5>';
                echo '<p class="card-text">'. $row["description"] .'</p>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No Request has been found.";
        }
        $conn = null;
        ?>
    </div>
</div>



<?php include 'components/footer.php'; ?>

<script src="https://unpkg.com/swiper@8/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>

</body>
</html>
